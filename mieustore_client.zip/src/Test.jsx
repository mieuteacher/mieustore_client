import { Route } from "react-router-dom";
import Example from "./pages/examples/Example";

export default <Route path="/examples" element={<Example></Example>}></Route>;
