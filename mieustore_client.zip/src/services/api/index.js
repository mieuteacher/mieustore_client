import userModule from "./modules/user";

export default {
  users: userModule,
};
