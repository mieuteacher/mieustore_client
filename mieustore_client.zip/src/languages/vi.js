export default {
    hello: "Chào Bạn",
    about: "Về Tôi"
}