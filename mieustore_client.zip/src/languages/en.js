export default {
    hello: "Hello Friend",
    about: "About Me"
}